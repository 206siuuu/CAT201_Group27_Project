package servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import config.DBConnection;
import constants.BookStoreConstants;
import constants.db.BooksDBConstants;

public class RatingBookServlet extends GenericServlet{
	public void service(ServletRequest req,ServletResponse res) throws IOException,ServletException
	{
		PrintWriter pw = res.getWriter();
		
		res.setContentType(BookStoreConstants.CONTENT_TYPE_TEXT_HTML);
		
//		String ratingT = req.getParameter(BooksDBConstants.COLUMN_RATING);
		int bRating = Integer.parseInt(req.getParameter(BooksDBConstants.COLUMN_RATING));
		
		
		try {
			Connection con = DBConnection.getCon();
			
			String bookIds = req.getParameter("selected");
			System.out.println("BookIds: "+bookIds );
			
//			Integer bRating = Integer.parseInt(ratingT);
			
			PreparedStatement ps = con.prepareStatement("update " + BooksDBConstants.TABLE_BOOK + " set " 
			+ BooksDBConstants.COLUMN_RATING +" = ? where " + BooksDBConstants.COLUMN_BARCODE + " = " + bookIds);
			
			ps.setInt(1, bRating);
			
			int k = ps.executeUpdate();
			if(k==1)
			{
				RequestDispatcher rd = req.getRequestDispatcher("Rating.html");
				rd.include(req, res);
				pw.println("<table class=\"tab\"><tr><td>Book Rated Successfully!<br/>Thank you for Rating!</td></tr></table>");
			}
			else
			{
				RequestDispatcher rd = req.getRequestDispatcher("Rating.html");
				pw.println("<table class=\"tab\"><tr><td>Failed to Rate Book! Fill up CareFully</td></tr></table>");
				rd.include(req, res);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
