package servlets;

import java.io.*;
import java.sql.*;
import javax.servlet.*;

import config.DBConnection;
import constants.BookStoreConstants;
import constants.db.BooksDBConstants;
import constants.db.UsersDBConstants;

public class ProcessPaymentServlet extends GenericServlet {
    public void service(ServletRequest req, ServletResponse res) throws IOException, ServletException {
        PrintWriter pw = res.getWriter();
        res.setContentType(BookStoreConstants.CONTENT_TYPE_TEXT_HTML);
        
        // addition
//        String ratingB = req.getParameter("rating");
        // addition
        
        try {
            Connection con = DBConnection.getCon();
            String bookIds = req.getParameter("selected");// comma seperated bookIds
            
            System.out.println("BookIds: "+bookIds );
            System.out.println("another:"+ req.getAttribute("bookIds"));
            if(bookIds == null) bookIds = "1";
            RequestDispatcher rd = req.getRequestDispatcher("receipt.html");
            rd.include(req, res);
            pw.println("<div class=\"container\">\r\n"
                    + "        <div class=\"card-columns\">");
            String query = "select * from " + BooksDBConstants.TABLE_BOOK + " where " +
                    BooksDBConstants.COLUMN_BARCODE + " in (" + bookIds + ")";
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            double total = 0.0;
            while (rs.next()) {
                int bPrice = rs.getInt(BooksDBConstants.COLUMN_PRICE);
                String bCode = rs.getString(BooksDBConstants.COLUMN_BARCODE);
                String bName = rs.getString(BooksDBConstants.COLUMN_NAME);
                String bAuthor = rs.getString(BooksDBConstants.COLUMN_AUTHOR);
                int bQty = rs.getInt(BooksDBConstants.COLUMN_QUANTITY);
                // new addtion
                String bCategory = rs.getString(BooksDBConstants.COLUMN_CATEGORY);
                int bRating = rs.getInt(BooksDBConstants.COLUMN_RATING);
                // new addtion
                System.out.println("bName " + bPrice);
                String qt = "qty_" + bCode;
                int quantity = Integer.parseInt(req.getParameter(qt));
                int amount = bPrice * quantity;
                total = total + amount;
                bQty = bQty - quantity;
                PreparedStatement ps1 = con.prepareStatement("update " + BooksDBConstants.TABLE_BOOK + " set "
                        + BooksDBConstants.COLUMN_QUANTITY + "=? where " + BooksDBConstants.COLUMN_BARCODE + "=?");
                ps1.setInt(1, bQty);
                ps1.setString(2, bCode);
                ps1.executeUpdate();
                
                // addition
//                if (ratingB != null) {
//                	int ratingBN = Integer.parseInt(ratingB);
//                	PreparedStatement ps2 = con.prepareStatement("update " + BooksDBConstants.TABLE_BOOK + " set " 
//                			+ BooksDBConstants.COLUMN_RATING + " = ? where " + BooksDBConstants.COLUMN_BARCODE + "=?");
//                	ps2.setInt(1, ratingBN);
////                	ps2.setInt(1, bRating);
//                	ps2.setString(2, bCode);
//                	ps2.executeUpdate();
//                	}
                // addtion
                pw.println(this.addBookToCard(bCode, bName, bAuthor, bPrice, bQty, bCategory, bRating, bookIds));
            }
            pw.println("</div>\r\n"
                    + "    </div>");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
//new addition
    public String addBookToCard(String bCode, String bName, String bAuthor, int bPrice, int bQty, String bCategory, int bRating, String bookIds) {
        String button = "<a href=\"#\" class=\"btn btn-info\">Order Placed</a>\r\n";
    
        
//        					" class=\"btn btn-info\">Rate</a>\r\n";
        
        // new addition
        return "<div class=\"card\">\r\n"
                + "                <div class=\"row card-body\">\r\n"
                + "                    <img class=\"col-sm-6\" src=\"logo.png\" alt=\"Card image cap\">\r\n"
                + "                    <div class=\"col-sm-6\">\r\n"
                + "                        <h5 class=\"card-title text-success\">" + bName + "</h5>\r\n"
                + "                        <p class=\"card-text\">\r\n"
                + "                        Author: <span class=\"text-primary\" style=\"font-weight:bold;\"> " + bAuthor
                + "</span><br>\r\n"
                + "                        </p>\r\n"
                + "                        \r\n"
                + "                    </div>\r\n"
                + "                </div>\r\n"
                + "                <div class=\"row card-body\">\r\n"
                + "                    <div class=\"col-sm-6\">\r\n"
                + "                        <p class=\"card-text\">\r\n"
                + "                        <span style='color:blue;'>Order Id: ORD" + bCode + "TM </span>\r\n"
                + "                        <br><span class=\"text-danger\">Item Yet to be Delivered</span>\r\n"
                + "                        </p>\r\n"
                + "                    </div>\r\n"
                + "                    <div class=\"col-sm-6\">\r\n"
                + "                        <p class=\"card-text\">\r\n"
                + "                        Amout Paid: <span style=\"font-weight:bold; color:green\"> &#8377; " + bPrice
                + " </span>\r\n"
                + "                        </p>\r\n"
                + button
                + "<h1 style='font-size:25px;'>Please rate the book </h1>\r\n"
                + "<form action=\"rating\" method=\"post\">\r\n"
                + "	 <input type='hidden' name = 'selected' value = " + bookIds + ">\r\n"
                + "    <input type=\"radio\" name=\"rating\" value=\"1\"> 1<br>\r\n"
                + "    <input type=\"radio\" name=\"rating\" value=\"2\"> 2<br>\r\n"
                + "    <input type=\"radio\" name=\"rating\" value=\"3\"> 3<br>\r\n"
                + "    <input type=\"submit\" class='color:blue;' value=\"Submit\">\r\n"
                + "  </form>"
                + "                    </div>\r\n"
                + "                </div>\r\n"
                + "            </div>";
    }
}
